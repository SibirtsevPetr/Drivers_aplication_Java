import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { CustomResponse } from '../interface/custom-response';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { Driver } from '../interface/driver';
import { Status } from '../enum/status.enum';

@Injectable({ providedIn: 'root' })
export class DriverService {
  private readonly apiUrl = 'http://localhost:8080';

  constructor(private http: HttpClient) { }

  drivers$ = <Observable<CustomResponse>>
  this.http.get<CustomResponse>(this.apiUrl + '/server/list')
  .pipe(
    tap(console.log),
    catchError(this.handleError)
  );

  save$ = (driver: Driver) => <Observable<CustomResponse>>
  this.http.post<CustomResponse>(this.apiUrl + '/server/save', driver)
  .pipe(
    tap(console.log),
    catchError(this.handleError)
  );


  reload$ = (name: string) => <Observable<CustomResponse>>
  this.http.get<CustomResponse>(this.apiUrl + '/server/reload/' + name)
  .pipe(
    tap(console.log),
    catchError(this.handleError)
  );

  filter$ = (status: Status, response: CustomResponse) => <Observable<CustomResponse>>
  new Observable<CustomResponse> (
    suscriber => {
      console.log(response);
      suscriber.next(
        status === Status.ALL ? { ...response, message: 'Server filtered by ' + status + 'status'} :
        {
          ...response,
          message: response.data.drivers
          .filter(driver => driver.status === status).length > 0 ? 'Server filtered by ' +
          status === Status.DRIVER_UP ? 'DRIVER_UP'
          : 'DRIVER_DOWN' + 'status' : 'No servers of ' + status + 'found',
          data: {drivers: response.data.drivers
            .filter(driver => driver.status === status) }
        }
      );
      suscriber.complete();
    }
  )
  .pipe(
    tap(console.log),
    catchError(this.handleError)
  );

  delete$ = (driverId: number) => <Observable<CustomResponse>>
  this.http.delete<CustomResponse>(this.apiUrl + '/server/delete/' + driverId)
  .pipe(
    tap(console.log),
    catchError(this.handleError)
  );


  private handleError(error: HttpErrorResponse): Observable<never> {
    console.log(error)
    return throwError('An Error occurred - Error code: ' + error.status);
  }
}
