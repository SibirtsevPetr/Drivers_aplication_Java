import { Component, OnInit } from '@angular/core';
import { BehaviorSubject, catchError, map, Observable, of, startWith } from 'rxjs';
import { DataState } from './enum/data-state.enum';
import { Status } from './enum/status.enum';
import { Location } from './enum/location.enum';
import { AppState } from './interface/app-state';
import { CustomResponse } from './interface/custom-response';
import { DriverService } from './service/driver.service';
import { NgForm } from '@angular/forms';
import { Driver } from './interface/driver';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  appState$: Observable<AppState<CustomResponse>>;
  readonly DataState = DataState;
  readonly Status = Status;
  readonly Location = Location;
  private filterSubject = new BehaviorSubject<string>('');
  private dataSubject = new BehaviorSubject<CustomResponse>(null);
  filterStatus$ = this.filterSubject.asObservable();
  private isLoading = new BehaviorSubject<boolean>(false);
  isLoading$ = this.isLoading.asObservable();


  constructor(private driverService: DriverService) {}

  ngOnInit(): void {
      this.appState$ = this.driverService.drivers$
      .pipe(
        map(response => {
          this.dataSubject.next(response);
          return { dataState: DataState.LOADED_STATE, appData: {...response, data: {drivers: response.data.drivers.reverse()}} }
        }),
        startWith({ dataState: DataState.LOADING_STATE }),
        catchError((error: string) =>  {
          return of({ dataState: DataState.ERROR_STATE, error })
        })
      );
  }

  reload(name: string): void {
    this.filterSubject.next(name);
    this.appState$ = this.driverService.reload$(name)
    .pipe(
      map(response => {
        const index = this.dataSubject.value.data.drivers.findIndex(driver =>
          driver.id === response.data.driver.id)
        this.dataSubject.value.data.drivers[index] = response.data.driver;
        this.filterSubject.next('');
        return { dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }
      }),
      startWith({ dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }),
      catchError((error: string) =>  {
        this.filterSubject.next('');
        return of({ dataState: DataState.ERROR_STATE, error })
      })
    );
  }


  filterDriver(status: Status): void {
    this.appState$ = this.driverService.filter$(status, this.dataSubject.value)
    .pipe(
      map(response => {
        return { dataState: DataState.LOADED_STATE, appData: response }
      }),
      startWith({ dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }),
      catchError((error: string) =>  {
        return of({ dataState: DataState.ERROR_STATE, error })
      })
    );
  }

  saveDriver(driverForm: NgForm): void {
    this.isLoading.next(true);
    this.appState$ = this.driverService.save$(driverForm.value as Driver)
    .pipe(
      map(response => {
        this.dataSubject.next(
          {...response, data: { drivers: [response.data.driver, ...this.dataSubject.value.data.drivers] } }
        );
        document.getElementById('closeModal').click();
        this.isLoading.next(false);
        driverForm.resetForm({ status: this.Status.DRIVER_DOWN})
        return { dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }
      }),
      startWith({ dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }),
    );
  }



  deleteDriver(driver: Driver): void {
    this.appState$ = this.driverService.delete$(driver.id)
    .pipe(
      map(response => {
        this.dataSubject.next(
          {...response, data: {drivers: this.dataSubject.value.data.drivers.filter(d => d.id != driver.id)}}
        );
        return { dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }
      }),
      startWith({ dataState: DataState.LOADED_STATE, appData: this.dataSubject.value }),
      catchError((error: string) =>  {
        this.filterSubject.next('');
        return of({ dataState: DataState.ERROR_STATE, error })
      })
    );
  }
}
