export enum Status {
  ALL = 'ALL', DRIVER_UP = 'DRIVER_UP', DRIVER_DOWN = 'DRIVER_DOWN'
}
