import { Status } from "../enum/status.enum";
import { Location } from "../enum/location.enum";

export interface Driver {
  id: number;
  name: string;
  personalData: string;
  workingHours: string;
  currentLocation: string;
  imageUrl: string;
  status: Status;
  statusLocation: Location;
}
